<?php 

$lang["datepicker_all_time"] = "";
$lang["datepicker_apply"] = "";
$lang["datepicker_cancel"] = "";
$lang["datepicker_custom"] = "";
$lang["datepicker_from"] = "";
$lang["datepicker_last_30"] = "";
$lang["datepicker_last_7"] = "";
$lang["datepicker_last_financial_year"] = "";
$lang["datepicker_last_month"] = "";
$lang["datepicker_last_year"] = "";
$lang["datepicker_same_month_last_year"] = "";
$lang["datepicker_same_month_to_same_day_last_year"] = "";
$lang["datepicker_this_financial_year"] = "";
$lang["datepicker_this_month"] = "";
$lang["datepicker_this_year"] = "";
$lang["datepicker_to"] = "";
$lang["datepicker_today"] = "";
$lang["datepicker_today_last_year"] = "";
$lang["datepicker_weekstart"] = "";
$lang["datepicker_yesterday"] = "";
