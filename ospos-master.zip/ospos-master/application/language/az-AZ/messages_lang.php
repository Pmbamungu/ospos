<?php 

$lang["messages_first_name"] = "Adı";
$lang["messages_last_name"] = "Soyadı";
$lang["messages_message"] = "Mesaj";
$lang["messages_message_placeholder"] = "Mesajınız burada...";
$lang["messages_message_required"] = "Mesaj tələb olunur";
$lang["messages_multiple_phones"] = "(Birdən çox alıcı halında, vergüllə ayrılan mobil nömrələri daxil edin)";
$lang["messages_phone"] = "Telefon";
$lang["messages_phone_number_required"] = "Telefon nömrəsi tələb olunur";
$lang["messages_phone_placeholder"] = "Mobil Nömrə(lər) burada...";
$lang["messages_sms_send"] = "SMS Göndər";
$lang["messages_successfully_sent"] = "Mesaj uğurla göndərildi: ";
$lang["messages_unsuccessfully_sent"] = "Mesaj uğursuz olaraq göndərildi: ";
