<?php
$lang["login_gcaptcha"] = "No soy un robot.";
$lang["login_go"] = "Ir";
$lang["login_invalid_gcaptcha"] = "Inválido, no soy un robot.";
$lang["login_invalid_installation"] = "La instalación no es correcta, comprueba el fichero php.ini.";
$lang["login_invalid_username_and_password"] = "Usuario o Contraseña no válidos.";
$lang["login_login"] = "Iniciar Sesión";
$lang["login_password"] = "Contraseña";
$lang["login_username"] = "Usuario";
