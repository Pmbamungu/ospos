<?php 

$lang["login_gcaptcha"] = "Saya bukan robot.";
$lang["login_go"] = "Lanjutkan";
$lang["login_invalid_gcaptcha"] = "Tidak valid saya bukan robot.";
$lang["login_invalid_installation"] = "Instalasi tidak benar, periksa file php.ini Anda.";
$lang["login_invalid_username_and_password"] = "Nama Pengguna/Kata Kunci Salah.";
$lang["login_login"] = "Masuk";
$lang["login_password"] = "Kata kunci";
$lang["login_username"] = "Nama Anda";
