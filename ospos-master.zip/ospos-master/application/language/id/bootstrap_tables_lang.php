<?php 

$lang["tables_all"] = "Semua";
$lang["tables_columns"] = "Kolom";
$lang["tables_hide_show_pagination"] = "Sembunyikan/Tampilkan paginasi";
$lang["tables_loading"] = "Memuat, tunggu ...";
$lang["tables_page_from_to"] = "Menampilkan {0} sampai {1} dari {2} baris";
$lang["tables_refresh"] = "Segarkan";
$lang["tables_rows_per_page"] = "{0} baris per halaman";
$lang["tables_toggle"] = "Beralih";
