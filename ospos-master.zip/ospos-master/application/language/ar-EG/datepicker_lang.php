<?php 

$lang["datepicker_all_time"] = "جميع الأوقات";
$lang["datepicker_apply"] = "تطبيق";
$lang["datepicker_cancel"] = "إلغاء";
$lang["datepicker_custom"] = "مخصص";
$lang["datepicker_from"] = "من";
$lang["datepicker_last_30"] = "أخر 30 يوم";
$lang["datepicker_last_7"] = "أخر سبعة أيام";
$lang["datepicker_last_financial_year"] = "السنة المالية الماضية";
$lang["datepicker_last_month"] = "أخر شهر";
$lang["datepicker_last_year"] = "السنة الماضية";
$lang["datepicker_same_month_last_year"] = "نفس الشهر من العام الماضي";
$lang["datepicker_same_month_to_same_day_last_year"] = "نفس الشهر حتى اليوم من السنة الماضية";
$lang["datepicker_this_financial_year"] = "السنة المالية الحالية";
$lang["datepicker_this_month"] = "هذا الشهر";
$lang["datepicker_this_year"] = "السنة الحالية";
$lang["datepicker_to"] = "إلى";
$lang["datepicker_today"] = "اليوم";
$lang["datepicker_today_last_year"] = "نفس اليوم من السنة الماضية";
$lang["datepicker_weekstart"] = "0";
$lang["datepicker_yesterday"] = "أمس";
