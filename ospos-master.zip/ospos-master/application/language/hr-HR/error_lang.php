<?php 

$lang["error_no_permission_module"] = "Nemate dozvolu za pristup modulu";
$lang["error_unknown"] = "ismeretlen";
