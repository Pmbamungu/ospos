<?php 

$lang["category_name_required"] = "E' richiesto il nome per la Categoria Spesa";
$lang["expenses_categories_add_item"] = "Aggiungi categoria";
$lang["expenses_categories_cannot_be_deleted"] = "Non puoi eliminare la Categoria Spese";
$lang["expenses_categories_category_id"] = "Id";
$lang["expenses_categories_confirm_delete"] = "Sei sicuro di voler eliminare la Categoria Spesa selezionata?";
$lang["expenses_categories_confirm_restore"] = "";
$lang["expenses_categories_description"] = "Descrizione Categoria";
$lang["expenses_categories_error_adding_updating"] = "Errore aggiungi/aggiorna Categoria Spesa";
$lang["expenses_categories_info"] = "Info Categoria Spesa";
$lang["expenses_categories_name"] = "Nome Categoria";
$lang["expenses_categories_new"] = "Nuova Categoria";
$lang["expenses_categories_no_expenses_categories_to_display"] = "Nessuna categoria da mostrare";
$lang["expenses_categories_none_selected"] = "Non hai selezionato nessuna Categoria Spesa";
$lang["expenses_categories_one_or_multiple"] = "Categoria Spesa";
$lang["expenses_categories_quantity"] = "Quantità";
$lang["expenses_categories_successful_adding"] = "Categoria Spesa aggiunta correttamente";
$lang["expenses_categories_successful_deleted"] = "Categoria spesa eliminata con successo";
$lang["expenses_categories_successful_updating"] = "Categoria Spesa aggiornata correttamente";
$lang["expenses_categories_update"] = "Aggiorna Categoria";
